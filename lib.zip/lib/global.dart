import 'dart:io';

class global {
  static bool isios = false;
  static File? myimage;
  static List<Map<String, dynamic>> all_contact = [
    {
      'image': null,
      'name': 'Tony Stark',
      'dec': 'Flutter',
      'time': "7:00 am",
      'phone': "905419181"
    },
    {
      'image': null,
      'name': 'Captain America',
      'dec': 'Hey There!',
      'time': "8:00 am",
      'phone': "905419181"
    },
    {
      'image': null,
      'name': 'Thor',
      'dec': 'Done',
      'time': "6:00 am",
      'phone': "905419181"
    },
    {
      'image': null,
      'name': 'Ant Man',
      'dec': 'You are my friend',
      'time': "9:00 am",
      'phone': "905419181"
    },
    {
      'image': null,
      'name': 'Spider Man',
      'dec': 'Its magis',
      'time': "10:00 am",
      'phone': "905419181"
    },
    {
      'image': null,
      'name': 'Thanos',
      'dec': 'ready for fight?',
      'time': "5:00 am",
      'phone': "905419181"
    },
  ];
}
